import React from "react";

function ContactTitle() {
    
    return(
        <div className="contact-title">
            <h2>Do you have a project?<br />
            I would love to help.</h2>
        </div>
    )
}

export default ContactTitle